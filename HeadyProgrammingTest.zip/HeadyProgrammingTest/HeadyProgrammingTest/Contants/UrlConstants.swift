//
//  UrlConstants.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import Foundation
import UIKit

let BASE_URL = "https://stark-spire-93433.herokuapp.com/json"

