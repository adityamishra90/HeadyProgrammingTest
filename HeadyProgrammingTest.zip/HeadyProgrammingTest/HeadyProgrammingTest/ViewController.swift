//
//  ViewController.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

