//
//  Model.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//
import Foundation

struct Model: Codable {
    let categories : [Categories]?
    let rankings : [Rankings]?
}

struct Categories : Codable {
    var id : Int?
    let name : String?
    let products : [Products]?
    let child_categories : [Int]
}

struct Rankings : Codable {
    let ranking : String?
    let products : [ProductsRankings]?
}

struct ProductsRankings : Codable {
    let id : Int?
}

struct Products : Codable{
    var id : Int
    var name: String?
    var variants: [Variant]?
}

struct Variant : Codable  {
    var id: Int?
    var color: String?
    var size: Int?
}

class BusinessLogic{
    var model: Model!
    static let sharedInstance = BusinessLogic()
    fileprivate var parentCategoriesIds = [Int]()
    func initialiseModelClass(model: Model){
        self.model = model
    }
    
    func getParentCategory()-> [Categories] {
        
        var topParentCategories = [Categories]()
        
        if let categories = self.model.categories
        {
            var intArr1 = [Int]()
            for item in categories{
                intArr1.append(item.id!)
            }
            let parentCategories = categories.filter({$0.child_categories.count > 0}) as [Categories]
            var intArr = [Int]()
            for item in parentCategories{
                intArr = intArr + item.child_categories
            }
            parentCategoriesIds = Array(Set(intArr).symmetricDifference(Set(intArr1)))
            
            
            for (index,_) in parentCategoriesIds.enumerated(){
                topParentCategories = topParentCategories + parentCategories.filter({$0.id == parentCategoriesIds[index]})
            }
        }
        return topParentCategories
    }
    
    func getRankingofProducts()-> [String] {
        
        var rankings = [String]()
        if self.model != nil
        {
        if let categories = self.model.rankings
        {
            for item in categories{
                rankings.append(item.ranking!)
            }
        }
        }
        return rankings
    }
    
    func getNameofProductBasedonRanking(ranking:String)-> [String] {
        var productid = [String]()
        if let categories = self.model.rankings
        {
            for item in categories {
                if item.ranking == ranking
                {
                let prodcuts : [ProductsRankings] = item.products!
                for ids in prodcuts {
                    let prodcutsid = ids.id
                    if let categories = self.model.categories
                    {
                        for item in categories{
                            if item.id == prodcutsid
                            {
                            productid.append(item.name!)
                            }
                        }
                    }
                }
            }
            }
        }
        return productid
    }
    
    func getAllNameofProductBasedonRanking()-> NSMutableArray {
        let productname = NSMutableArray()
        let productnamearray = NSMutableArray()

        if let rankings = self.model.rankings
        {
            for item in rankings {
                        if let categories = self.model.categories
                        {
                            for categoriesitems in categories{
                                    let productarray: [Products] = categoriesitems.products!
                                    for productarrayitems in productarray{
                                        productname.add(productarrayitems.name!)
                                    }
                            }
                            
                        }
                productnamearray.add(productname)
            }
        }
        return productnamearray
    }
    
    func getCategoryOfID(categoryId : Int) -> Categories?{
        let category = model.categories?.filter({$0.id == categoryId}).first
        return category!
    }
}
