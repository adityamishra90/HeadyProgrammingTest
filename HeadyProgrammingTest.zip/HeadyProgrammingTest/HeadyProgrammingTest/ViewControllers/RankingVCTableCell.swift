//
//  RankingVCTableCell.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import UIKit

class RankingVCTableCell: UITableViewCell,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectinView: UICollectionView!
    
    @IBOutlet weak var titleLabel: UILabel!
    fileprivate let cellIdentifier = "CollectionCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupCollectionView()
    }

    
    func setCellRankingData(ranking: String){
        titleLabel.text = ranking
        DispatchQueue.main.async {
            self.collectinView.reloadData()
        }
    }
    
    func setupCollectionView(){
        self.collectinView.register(UINib.init(nibName: "RankingCollectionCell", bundle: nil), forCellWithReuseIdentifier: cellIdentifier)
        DispatchQueue.main.async {
            self.collectinView.reloadData()
        }
    }

    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        for item in BusinessLogic.sharedInstance.getRankingofProducts(){
           return BusinessLogic.sharedInstance.getNameofProductBasedonRanking(ranking: item).count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as? RankingCollectionCell
        let array = BusinessLogic.sharedInstance.getAllNameofProductBasedonRanking()
        for loops in 0..<array.count
        {
            let nametitle:NSArray = array[loops] as! NSArray
            cell?.ccategiryTitle.text = nametitle[indexPath.row] as? String
        }
        return cell!
    }
    


    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        return CGSize(width: 270 , height: 160);
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }
    
}
