//
//  ProductCollectionCell.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import UIKit

class ProductCollectionCell: UICollectionViewCell {

    @IBOutlet weak var size: UILabel!
    @IBOutlet weak var color: UILabel!
    var variant: Variant!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
 
    func setCellProductDataFor(variant: Variant) {
        self.variant = variant
        if let variantSize = variant.size{
            size.text = "Size: " + "\(variantSize)"
        }
        else{
            size.text = ""
        }

        color.text = "Color: " + "\(variant.color!)"
    }
}
