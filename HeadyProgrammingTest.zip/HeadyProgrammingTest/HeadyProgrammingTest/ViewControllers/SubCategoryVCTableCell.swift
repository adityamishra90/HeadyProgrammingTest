//
//  SubCategoryVCTableCell.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import UIKit

protocol SubCategoryVCTableCellDelegate: NSObjectProtocol{
func subCategoryCellSelectedID(product: Products)
}

class SubCategoryVCTableCell: UITableViewCell {

    @IBOutlet weak var collectinView: UICollectionView!
    
    @IBOutlet weak var titleLabel: UILabel!
    fileprivate var products: [Products]!
    
    fileprivate let cellIdentifier = "CollectionCell"
    weak var delegate: SubCategoryVCTableCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupCollectionView()
    }

    func setCellCategoryData(categoryId: Int){
        
        if let model = BusinessLogic.sharedInstance.getCategoryOfID(categoryId: categoryId){
            titleLabel.text = model.name
            products = model.products
        }
        DispatchQueue.main.async {
            self.collectinView.reloadData()
        }
    }
    
    func setupCollectionView(){
        self.collectinView.register(UINib.init(nibName: "SubCategoryCollectionCell", bundle: nil), forCellWithReuseIdentifier: cellIdentifier)
        collectinView.dataSource = self
        DispatchQueue.main.async {
            self.collectinView.reloadData()
        }
    }

    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}

extension SubCategoryVCTableCell: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let products = products
        {
            return products.count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as? SubCategoryCollectionCell
        cell?.setCellCategoryDataFor(product: products[indexPath.row])
        return cell!
    }
    
}


extension SubCategoryVCTableCell: UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.subCategoryCellSelectedID(product: products[indexPath.row])
    }
}


extension SubCategoryVCTableCell: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        return CGSize(width: 270 , height: 160);
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }
    
}
