//
//  RankingCollectionCell.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import UIKit

class RankingCollectionCell: UICollectionViewCell {

    @IBOutlet weak var ccategiryTitle: UILabel!
    var product: Products!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
