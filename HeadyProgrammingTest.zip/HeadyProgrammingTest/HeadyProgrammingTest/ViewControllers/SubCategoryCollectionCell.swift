//
//  SubCategoryCollectionCell.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import UIKit

class SubCategoryCollectionCell: UICollectionViewCell {

    @IBOutlet weak var ccategiryTitle: UILabel!
    var product: Products!
    
    @IBOutlet weak var arrivedDate: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setCellCategoryDataFor(product: Products) {
        self.product = product
        ccategiryTitle.text = product.name
    }
}
