//
//  RankingVC.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import UIKit

class RankingVC: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var categoryTable: UITableView!
    let cellIdentifier = "tabelCell"
    var nameranking = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCellNib()
        self.callrankingData()
    }
    
    func callrankingData(){
        self.nameranking = BusinessLogic.sharedInstance
            .getRankingofProducts()
        DispatchQueue.main.async {
            self.categoryTable.reloadData()
        }
    }
    
    func registerCellNib(){
        let nib = UINib(nibName: "RankingVCTableCell", bundle: nil)
        categoryTable.register(nib, forCellReuseIdentifier: cellIdentifier)
        self.categoryTable.rowHeight = 280
        DispatchQueue.main.async {
            self.categoryTable.reloadData()
        }
    }
    
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.nameranking.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.categoryTable.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! RankingVCTableCell
        cell.selectionStyle = .none;
        cell.setCellRankingData(ranking: self.nameranking[indexPath.row])
        
        return cell
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}




