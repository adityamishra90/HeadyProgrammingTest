//
//  CategoryCollectionCell.swift
//  HeadyProgrammingTest
//
//  Created by VideoTap on 01/10/19.
//  Copyright © 2019 VideoTap. All rights reserved.
//

import UIKit

class CategoryCollectionCell: UICollectionViewCell {

    @IBOutlet weak var ccategiryTitle: UILabel!
    var categoryData: Categories!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setCellCategoryDataFor(categoryId: Int) {
        if let category = BusinessLogic.sharedInstance.getCategoryOfID(categoryId: categoryId){
            self.categoryData = category
            ccategiryTitle.text = self.categoryData.name
        }
    }

}
